'use strict';

angular.module('Courses')

.controller('CourseController',
    ['$scope','AuthenticationService','$http',
    function ($scope, AuthenticationService,$http) {
    	var token = AuthenticationService.GetToken();
    	console.log(token);
    	store.products = [];
    	$http.get('http://localhost/moodle/webservice/rest/server.php?wstoken='+token+'&wsfunction=gradereport_user_get_grades_table&moodlewsrestformat=json&courseid=2').success(function(data){
      		store.products = data;
      		console.log(data);
    	});

    }]);
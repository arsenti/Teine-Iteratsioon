﻿'use strict';

angular.module('Home')

.controller('StoreController',
    ['$scope','AuthenticationService','$http',
    function ($scope, AuthenticationService,$http) {
    	var store = this;
    	var token = AuthenticationService.GetToken();
    	store.products = [];
    	$http.get('http://localhost/moodle/webservice/rest/server.php?wstoken='+token+'&wsfunction=gradereport_user_get_grades_table&moodlewsrestformat=json&courseid=2').success(function(data){
      		store.products = data;
    	});
    	var courses = this;
    	courses.information = [];
    	$http.get('http://localhost/moodle/webservice/rest/server.php?wstoken='+token+'&wsfunction=core_course_get_courses&moodlewsrestformat=json').success(function(response){
      		console.log(response);
      		courses.information = response;
    	});
      function getCourseId(id) {
      console.log("works");
}

    }]);